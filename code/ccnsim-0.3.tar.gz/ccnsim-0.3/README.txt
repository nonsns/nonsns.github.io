                  / _____)_	      
  ____ ____ ____ ( (____ (_)_ __ ___  
 / ___) ___)  _ \ \____ \| | '_ ` _ \ 
( (__( (___| | | |_____) | | | | | | |
 \____)____)_| |_(______/|_|_| |_| |_|


Thank you for joining the ccnSim community!  This is ccnSim v0.3.


To install ccnSim, please follow the instructions on INSTALL.txt  After you
succesfully installed ccnSim, run your first simulation with:

	./ccnSim -u Cmdenv

The default omnetpp.ini provided simulates a simple topology and scenario.
Notice that the scenario is merely illustrative of the ini files syntax; 
for a set of more representative scripts and scenarios please refer to the
ccnSim website. 

After the  simulation completes, a set of output files is produced under the
directory "results/". For more details about the output files, please refer to
the ccnSim manual.
